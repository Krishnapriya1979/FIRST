Address Book Project in java with MVC, |Singleton and DAO Design Pattern


To run the project follow the instructions given below:

1.Create a table 'addressbook' with the following structure in MySQL

	Fieldname         Type
	
	name		    varchar2(20)
	mob		    varchar2(15)
	email		    varchar2(50)

2.Open the project in Netbeans IDE.

3.Resolve the jar file issues if any. (MySQL Driver)

4.Change the  file dbconfig.properties as per your database name ,user name and password